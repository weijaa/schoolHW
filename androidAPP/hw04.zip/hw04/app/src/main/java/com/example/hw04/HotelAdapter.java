package com.example.hw04;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class HotelAdapter extends ArrayAdapter<Hotel> {
    Context context;

    public HotelAdapter(Context context, List<Hotel> items) {
        super(context,0, items);
        this.context = context;
    }
    public View getView(int position , View convertView, ViewGroup parent){
        //System.out.println("123456789");
        LayoutInflater inflater = LayoutInflater.from(context);
        LinearLayout itemlayout = null;
        if(convertView == null){
            itemlayout = (LinearLayout) inflater.inflate(R.layout.hotel_item,null);
        }else{
            itemlayout = (LinearLayout) convertView;
        }
        Hotel item = (Hotel) getItem(position);
        TextView name = (TextView) itemlayout.findViewById(R.id.name);
        TextView location = (TextView) itemlayout.findViewById(R.id.location);
        TextView phone = (TextView) itemlayout.findViewById(R.id.phone);
        //System.out.println("pppppppp");
        name.setText(item.getName());
        location.setText(item.getLocation());
        phone.setText(item.getPhone());
        return itemlayout;
    }
}
