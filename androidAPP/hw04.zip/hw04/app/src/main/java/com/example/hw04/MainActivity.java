package com.example.hw04;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    double[] xx = new double[97];
    double[] yy = new double[97];
    String[] nameHotel = new String[97];
    private HotelAdapter adapter = null;
    private static final int LIST_HOTEL = 1;
    private Handler handler = new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                case LIST_HOTEL: {
                    List<Hotel> hotels = (List<Hotel>) msg.obj;
                    refreshHotelList(hotels);
                    break;
                }
            }
        }
    };
    private void refreshHotelList(List<Hotel> hotels) {
        adapter.clear();
        adapter.addAll(hotels);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView hotelView = findViewById(R.id.listview);
        adapter = new HotelAdapter(this,new ArrayList<Hotel>());
        hotelView.setAdapter(adapter);
        getHotelInfo();
        hotelView.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent it = new  Intent(this,myMap.class);
        it.putExtra("X",xx[position]);
        it.putExtra("Y",yy[position]);
        it.putExtra("NAME",nameHotel[position]);

        startActivity(it);
    }
    int num=0;
    public class FirebaseThread extends Thread {
        private DataSnapshot dataSnapshot;
        public FirebaseThread(DataSnapshot dataSnapshot){
            this.dataSnapshot = dataSnapshot;
        }
        public void run(){
            List<Hotel> lsHotels = new ArrayList<>();
            int a;
            for (DataSnapshot ds : dataSnapshot.getChildren()){
                DataSnapshot dsName = ds.child("Name");
                DataSnapshot dsLocation = ds.child("Add");
                DataSnapshot dsPhone = ds.child("Tel");
                DataSnapshot dsx = ds.child("Px");
                DataSnapshot dsy = ds.child("Py");


                String name = (String)dsName.getValue();
                String location = (String)dsLocation.getValue();
                String phone = (String)dsPhone.getValue();
                double x = (double)dsx.getValue();
                double y = (double)dsy.getValue();
                Hotel aHotel = new Hotel();
                aHotel.setName(name);
                aHotel.setLocation(location);
                aHotel.setPhone(phone);

                xx[num] = x;
                yy[num] = y;
                nameHotel[num] = name;
                num++;
                lsHotels.add(aHotel);
                //Log.v("hw04",aHotel.getName()+"  "+aHotel.getLocation()+ " " + aHotel.getPhone() );

                Message msg = new Message();
                msg.what = LIST_HOTEL;
                msg.obj = lsHotels;
                handler.sendMessage(msg);
            }
        }
    }
    public void getHotelInfo(){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                new FirebaseThread(dataSnapshot).start();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.v("hw04","ggggggg");
            }
    });
    }

}
