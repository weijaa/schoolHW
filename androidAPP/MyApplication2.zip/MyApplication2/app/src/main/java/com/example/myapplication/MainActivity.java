package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    TextView mail, pass, passTwice,out;
    RadioGroup sex;
    CheckBox[] skill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mail = findViewById(R.id.mail);
        out = findViewById(R.id.output);
        pass = findViewById(R.id.pass);
        passTwice = findViewById(R.id.passTwice);
        sex = findViewById(R.id.sex);
        skill = new CheckBox[4];
        skill[0] = findViewById(R.id.ck1);
        skill[1] = findViewById(R.id.ck2);
        skill[2] = findViewById(R.id.ck3);
        skill[3] = findViewById(R.id.ck4);


    }
    public void reset (View v) {
        out.setText("");
        mail.setText("");
        pass.setText("");
        passTwice.setText("");
        sex.check(R.id.female);
        findViewById(R.id.warn).setVisibility(View.INVISIBLE);
    }
    public void check (View v){
        if(!mailCheck(mail.getText().toString())){}
        else if(!passCheck(pass.getText().toString())){}
        else if(!passTwice.getText().toString().equals(pass.getText().toString())) {
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            out.setText("請確認密碼是否正確");
        }
        else if(!(skill[0].isChecked() || skill[1].isChecked() || skill[2].isChecked() || skill[3].isChecked())){
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            out.setText("請選取專長");
        }
        else{
            findViewById(R.id.warn).setVisibility(View.INVISIBLE);
            out.setText(mail.getText().toString()+"註冊成功");
        }
    }
    protected boolean mailCheck(String mail){

        if(mail.isEmpty()){
            out.setText("帳號為必填欄位");
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            return false;
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(mail).matches()){
           out.setText("Email格式錯誤");
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
           return false;
        }else return true;
    }
    protected boolean passCheck(String pass){
        int num=0,up=0,i=0;
        while(i < pass.length()){
            char chr = pass.charAt(i);
            if(Character.isUpperCase(chr)) up++;
            else if(Character.isDigit(chr)) num++;
            i++;
        }
        if(pass.isEmpty()){
            out.setText("密碼為必填欄位");
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            return false;
        }else if(pass.length() < 8){
            out.setText("密碼長度必須大於8");
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            return false;
        }else if(num == 0){
            out.setText("密碼需包含一個以上的數字");
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            return false;
        }else if(up == 0){
            out.setText("密碼需包含一個以上的大寫字元");
            findViewById(R.id.warn).setVisibility(View.VISIBLE);
            return false;
        }else return true;
    }

}



