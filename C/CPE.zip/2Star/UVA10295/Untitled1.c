#include<stdio.h>
int main(void) {
	printf("0X%0X\n", EOF);
}
