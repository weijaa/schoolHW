package tmppppp;

public class temperature {
	public static void main(String[] argv) {
		int base = 10;
		int height = 3;
		int radius = 3;
		int area;
		float circumference;
		area = base * height /2 ;
		circumference = (float) (2 *radius *3.14);
		System.out.println("The area of the triangle is "+ area);
		System.out.println("The circumference of the circle is "+ circumference);
		
	}
}
