
public class Q6 {
	public static void main(String[] argv) {
		Truck[] truck = new Truck[3];
		truck[0] = new Truck("Jack","Audi",5,20.2,4);
		truck[1] = new Truck("Jack","Audi",5,20.2,4);
		truck[2] = new Truck("John","Audi",5,16.7,6);
		
		for(int i =0;i<truck.length;i++) {
			System.out.println(truck[i].toString());
		}
		System.out.println("Is Truck[0] equal to Truck[1]? "+ truck[0].equals(truck[1]));
		System.out.println("Is Truck[1] equal to Truck[2]? "+ truck[1].equals(truck[2]));
	}
}
