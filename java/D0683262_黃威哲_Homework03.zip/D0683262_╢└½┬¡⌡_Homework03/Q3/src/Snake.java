
public class Snake extends Alien{
	public Snake() {
		super();
	}
	public Snake(String name, int health) {
		super(name, health);
	}
	public int getDamage() {
		return 10;
	}
}
