
public class Ogre extends Alien{
	public Ogre() {
		super();
	}
	public Ogre(String name, int health) {
		super(name, health);
	}
	public int getDamage() {
		return 6;
	}
}
