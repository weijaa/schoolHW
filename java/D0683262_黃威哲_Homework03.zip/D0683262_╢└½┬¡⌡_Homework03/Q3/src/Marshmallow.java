
public class Marshmallow extends Alien{
	public Marshmallow() {
		super();
	}
	public Marshmallow(String name, int health) {
		super(name,health);
	}
	public int getDamage() {
		return 1;
	}
}
